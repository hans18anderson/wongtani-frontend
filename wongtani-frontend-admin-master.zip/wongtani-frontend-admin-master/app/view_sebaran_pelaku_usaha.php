<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class view_sebaran_pelaku_usaha extends Model
{
    protected $table = 'v_sebaran_pelaku_usaha';

}

